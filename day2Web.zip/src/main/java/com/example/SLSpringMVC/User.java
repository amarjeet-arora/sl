package com.example.SLSpringMVC;

public class User {
	
	private String name;
	private String pass;
	private String email;
	private String city;
	public User(String name, String pass, String email, String city) {
		super();
		this.name = name;
		this.pass = pass;
		this.email = email;
		this.city = city;
	}
	@Override
	public String toString() {
		return "User [name=" + name + ", pass=" + pass + ", email=" + email + ", city=" + city + "]";
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

}
