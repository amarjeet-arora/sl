package com.example.SLSpringMVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SlSpringMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SlSpringMvcApplication.class, args);
	}

}
