package com.example.springSL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSlApplicationTests {

	@Test
	void contextLoads() {
	}

}
