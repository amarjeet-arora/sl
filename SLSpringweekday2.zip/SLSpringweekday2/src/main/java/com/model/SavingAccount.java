package com.model;

import org.springframework.stereotype.Component;

 public class SavingAccount implements InterestCalculator {

	private double roi = 4.8;
	private int duration = 5;

	public double getRoi() {
		return roi;
	}

	public void setRoi(double roi) {
		this.roi = roi;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	@Override
	public double calculate(double amount) {
		// TODO Auto-generated method stub
		return amount*roi/duration;
	}

	public SavingAccount() {
		System.out.println("inside saving");
	}
}
