package com.model;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

 
public class FixedAccount implements InterestCalculator {

	private double roi = 5.8;
	private int duration = 6;

	public double getRoi() {
		return roi;
	}

	public void setRoi(double roi) {
		this.roi = roi;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	@Override
	public double calculate(double amount) {
		// TODO Auto-generated method stub
		return amount*roi/duration;
	}
	public FixedAccount() {
		System.out.println("inside fixed account");
	}

}
