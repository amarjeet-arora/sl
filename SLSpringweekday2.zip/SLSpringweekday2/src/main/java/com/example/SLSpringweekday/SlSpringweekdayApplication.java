package com.example.SLSpringweekday;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SlSpringweekdayApplication {

	public static void main(String[] args) {
		SpringApplication.run(SlSpringweekdayApplication.class, args);
	}

}
