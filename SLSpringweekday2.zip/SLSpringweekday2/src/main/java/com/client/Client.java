package com.client;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.service.CalculatorService;

public class Client {

	public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext ctx= new AnnotationConfigApplicationContext(MainApp.class);
		
		
		CalculatorService cs=(CalculatorService)ctx.getBean("service");
		
		System.out.println(cs.service(4576));
		ctx.close();
		 

	}

}
