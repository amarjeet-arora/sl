package com.service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.model.InterestCalculator;

 
 
public class CalculatorService {
	
	
	 
	private InterestCalculator ic;

	public InterestCalculator getIc() {
		return ic;
	}

	public void setIc(InterestCalculator ic) {
		this.ic = ic;
	}
	
	public CalculatorService(InterestCalculator ic) {
		super();
		this.ic = ic;
	}

	public double service(double amount) {
		return ic.calculate(amount);
	}
	@PostConstruct
	public void callbefore() {
		System.out.println("calling before");
	}
	@PreDestroy
	public void callAfter() {
		System.out.println("calling After");
	}
	

}
