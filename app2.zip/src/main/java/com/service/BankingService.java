package com.service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.model.InterestCalculator;

@Service(value = "service")
public class BankingService {
	
	@Autowired
	@Qualifier(value = "fa")
	private InterestCalculator ic;

	public InterestCalculator getIc() {
		return ic;
	}

	public void setIc(InterestCalculator ic) {
		this.ic = ic;
	}
	
	
	public double service(double amount) {
		return ic.calculate(amount);
	}
public BankingService() {
	System.out.println("inside service");
}
@PostConstruct
public void init() {
	System.out.println("inside service init");
}
@PreDestroy
public void destroy() {
	System.out.println("inside service destroy");
}

}
