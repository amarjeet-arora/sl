package com.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.model.User;

@Service
public class UserService {
	
	ArrayList<User> al= new ArrayList<User>();
	
	public boolean loginvalid(String name,String pass) {
		if(name.equals("admin") && pass.equals("manager")) {
			
			return true;
		}
		return false;
	}
	
	public boolean register(String name,String pass,String email,String city) {
		al.add(new User(name, pass, email, city));
		
		System.out.println(al);
		return true;
		
	}
	
	

}
