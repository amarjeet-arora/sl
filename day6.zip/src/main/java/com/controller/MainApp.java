package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.service.UserService;

 
@RestController
@RequestMapping("/mainapp")
public class MainApp {

	@Autowired
	private UserService service;

	@PostMapping("/login")

	public String loginValid(@RequestParam("uname") String name, @RequestParam("pass") String pass) {
		if (service.loginvalid(name, pass)) {
			return "login is valid";
		}
		return "login is invalid";
	}

	@PostMapping("/registration")
	public String registrationUser(@RequestParam("uname") String name, @RequestParam("pass") String pass,
			@RequestParam("email") String email, @RequestParam("city") String city) {

		if (service.register(name, pass, email, city)) {
			return " user added successfully";
		}
		return " registration failed";

	}

}
