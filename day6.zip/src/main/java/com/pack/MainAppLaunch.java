package com.pack;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com")
public class MainAppLaunch {
	
	public static void main(String[] args) {
		
		SpringApplication.run(MainAppLaunch.class, args);
	}

}
